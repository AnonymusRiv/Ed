var searchData=
[
  ['deque_62',['deque',['../classQueue.html#acdf4b7ced62c0616a67809178495e6fc',1,'Queue']]]
];
