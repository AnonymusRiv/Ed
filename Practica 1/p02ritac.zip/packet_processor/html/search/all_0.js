var searchData=
[
  ['_5ffinish_5ftime_0',['_finish_time',['../classPacketProcessor.html#a124abf77cd8cecda5d290a4f76ecf5bb',1,'PacketProcessor']]],
  ['_5fmax_5fsize_1',['_max_size',['../classPacketProcessor.html#ae2d06c81665f8e116b7a542a02e0a713',1,'PacketProcessor']]]
];
