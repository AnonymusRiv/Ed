var searchData=
[
  ['remove_85',['remove',['../classSList.html#a3746babfb2fe28ffdf9ad3a14e187bed',1,'SList']]]
];
