var searchData=
[
  ['back_58',['back',['../classQueue.html#af3d0b97363f6418a0350bde54d7344ff',1,'Queue']]]
];
